package myMath;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Monom m1=new Monom(7,2);
		Monom m2=new Monom(6,1);
		Monom m3=new Monom(5,0);
		Polynom p=new Polynom();
		p.add(m1);
		p.add(m2);
		p.add(m3);
		Monom t0=new Monom(1,2);
		Monom t1=new Monom(-2,0);
		Polynom p0=new Polynom();
		p0.add(t0);
		p0.add(t1);
		p.add(p0);
		System.out.println(p.toString());		
	}

}
