package myMath;

import java.util.ArrayList;
import java.util.Iterator;
import myMath.Monom;
/**
 * This class represents a Polynom with add, multiply functionality, it also should support the following:
 * 1. Riemann's Integral: https://en.wikipedia.org/wiki/Riemann_integral
 * 2. Finding a numerical value between two values (currently support root only f(x)=0).
 * 3. Derivative
 * 
 * @author Boaz
 *
 */
public class Polynom implements Polynom_able{

	private ArrayList<Monom> pol=new ArrayList<Monom>();
	@Override
	public double f(double x) {
		// TODO Auto-generated method stub
		Iterator<Monom> mi=this.iteretor();
		double res=0;
		while (mi.hasNext()) {
			Monom temp=mi.next();
			res=res+temp.f(x);
			/*
			 * jumping with the iterator and summing the result in each monom
			 */
		}
		return res;
	}

	@Override
	public void add(Monom m1) {
		Iterator<Monom> mi=this.iteretor();
		boolean flage=false;
		/*
		 * this flage is for preventing double adding 
		 */
		while(mi.hasNext()){
			Monom temp=mi.next(); 
			if(temp.get_coefficient()==0) 
				return;
			if (temp.get_power()==m1.get_power()) {
				flage=true;
				temp.add(m1);
			}
		}
		if(flage==false)
		this.pol.add(m1);
	}

	@Override
	public void add(Polynom_able p1) {
		// TODO Auto-generated method stub
		ArrayList<Monom> res=new ArrayList<Monom>();
		Iterator<Monom> mi_p=p1.iteretor();
		Iterator<Monom> mi_t=this.iteretor();
		while(mi_p.hasNext()) {
			Monom temp_p=mi_p.next();
			while(mi_t.hasNext()) {
				Monom temp_t=mi_t.next();
				Monom copy=new Monom(temp_t);
				copy.add(temp_p);
				res.add(copy);
			}
			mi_t=this.iteretor();
			/*
			 * this for re initial the inner loop
			 */
		}
		this.pol.clear();
		for(Monom it:res) {
			this.add(it);
		}
	}

	@Override
	public void substract(Polynom_able p1) {
		// TODO Auto-generated method stub
		Iterator<Monom> mi=p1.iteretor();
		while(mi.hasNext()) {
			Monom temp=mi.next();
			temp.set_coefficient(temp.get_coefficient()*-1);
			this.add(temp);
		}
	}

	@Override
	public void multiply(Polynom_able p1) { 
		// TODO Auto-generated method stub
		ArrayList<Monom> res=new ArrayList<Monom>();
		Iterator<Monom> mi_p=p1.iteretor();
		Iterator<Monom> mi_t=this.iteretor();
		while(mi_p.hasNext()) {
			Monom temp_p=mi_p.next();
			while(mi_t.hasNext()) {
				Monom temp_t=mi_t.next();
				Monom copy=new Monom(temp_t);
				copy.multiply(temp_p);
				res.add(copy);
			}
			 mi_t=this.iteretor();
		}
		this.pol.clear();
		for (Monom it:res) {
			this.add(it);
		}
	}

	@Override
	public boolean equals(Polynom_able p1) {
		// TODO Auto-generated method stub
		boolean flage = false;
		boolean comp = true;
		Iterator<Monom> mi_p=p1.iteretor();
		Iterator<Monom> mi_t=this.iteretor();
		while(mi_p.hasNext()) {
			Monom temp_p=mi_p.next();
			while(mi_t.hasNext()&&flage==false) {
				Monom temp_t=mi_t.next();
				if(temp_t.get_coefficient()==temp_p.get_coefficient()&&temp_t.get_power()==temp_p.get_power()) {
					flage=true;
				}
			}
			comp=comp&&flage;
			flage=false;
			mi_t=this.iteretor();
		}
		return comp;
	}

	@Override
	public boolean isZero() {
		// TODO Auto-generated method stub
		boolean flage=true;
		Iterator<Monom> mi=this.iteretor();
		while(mi.hasNext()) {
			Monom temp=mi.next();
			if(temp.get_coefficient()!=0)
				flage=false;
		}
		return flage;

	}

	@Override
	public double root(double x0, double x1, double eps) {
		if(this.f(x0)*this.f(x1)>0) {
			throw new RuntimeException("error");
		}
		double y = Math.abs(this.f(x0) - this.f(x1));
		if (y>eps) {
			double mid = (x0+x1)/2;
			double temp = this.f(mid);
			double move = this.f(x0)*temp;
			if(move<0) 
				return root(x0,mid,eps);
			else 
				return root(mid,x1,eps);
		}
		return x0;
	}

	@Override
	public Polynom_able copy() {
		// TODO Auto-generated method stub
		Polynom_able copied = new Polynom() ;
		Iterator<Monom> mi=this.iteretor();
		while(mi.hasNext()) {

			Monom temp=mi.next();

			copied.add(new Monom(temp));												
		}
		return copied;
	}

	@Override
	public Polynom_able derivative() {
		// TODO Auto-generated method stub
		Polynom_able copied = new Polynom() ;
		Iterator<Monom> mi=this.iteretor();
		while(mi.hasNext()) {
			Monom temp=mi.next();
			Monom temp2=new Monom(temp);
			temp2.nigzeret();
			copied.add(temp2);												
		}												
		return copied;	
	}

	@Override
	public double area(double x0, double x1, double eps) {
		double count= 0;	
		int t=(int)Math.abs((x1-x0)/eps);
		for (int i = 0; i < t; i++) {
			double temp=this.f(x0);
			if(temp>0)
				count=count+this.f(x0) * eps;
			x0=x0+eps;
		}
		return count;
	}
	public Polynom(String input)  {
		String[] Monoms = input.split(" "); 
		if(Monoms.length%2 == 0) 
			throw new RuntimeException("error");
		for (int i=0;i < Monoms.length;i=i+2) {
			if (i==0)
				this.pol.add(new Monom(Monoms[i]));
			else {
				String ans=Monoms[i]+Monoms[i+1];
				this.pol.add(new Monom(ans));
			}
		}
	}
	public Polynom() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public Iterator<Monom> iteretor() {
		return this.pol.iterator();
	}
	@Override
	public String toString() {
		Iterator<Monom> mi=this.iteretor();
		String []res=new String[this.pol.size()];
		int jump=0;
		while(mi.hasNext()) {
			Monom temp=mi.next();
			res[jump]="+"+temp.get_coefficient()+"x^"+temp.get_power();
			System.out.print(res[jump]+" ");
			jump++;
		}
		return "";
	}
	// ********** add your code below ***********

}
