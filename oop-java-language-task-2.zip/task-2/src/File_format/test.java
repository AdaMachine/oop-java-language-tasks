package File_format;

import java.io.File;

public class test {
	
	public static void main(String[] args) {
		
//
//	Csv2kml.csv2kml("C:\\Users\\micha\\Desktop\\files\\game_1543693911932.csv");
//		
		//MultiCSV.dir2kml("C:\\Users\\Natalie\\Desktop\\n");
		System.out.println("done");
	}
}
