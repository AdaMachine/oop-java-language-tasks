
# OOP_EX2-Ex4

This Github project is an educational example for using git & github as part of the Object Oriented Programming course in Ariel University. 
The main focus of this project is to allow an online suppoer of Ex2, Ex3, Ex4 which are all related to a GIS like system.
