package Listeners;

import GUI.Canvas;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * {@code java.awt.event.MouseListener, java.awt.event.MouseMotionListener} class to listen and react to mouse events (clicks and mouse movement)
 *  when adding a new regular pacman.
 */
public class AddPlayerMouseListener extends MouseAdapter {
    private Canvas canvas;

    /**
     * Constructor.
     * @param canvas The canvas on which to track the mouse events, and send any relevant updates to it.
     */
    public AddPlayerMouseListener(Canvas canvas) {
        this.canvas = canvas;
    }

    /**
     * Method to be called when a mouse is clicked.
     * @param mouseEvent the mouse event resulting from a mouse click.
     */
    @Override
    public void mouseClicked(MouseEvent mouseEvent) {
        // ask the canvas to accept the current pseudo pacman
        canvas.acceptPseudoPlayer();
    }

    /**
     * Method to be called when a mouse is moved over the canvas.
     * @param mouseEvent the mouse event resulting from a mouse motion.
     */
    @Override
    public void mouseMoved(MouseEvent mouseEvent) {
        canvas.updatePseudoPlayer(mouseEvent.getX(), mouseEvent.getY());
    }
}
