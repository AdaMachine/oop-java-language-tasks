package Listeners;

import Coords.MyCoords;
import GUI.Canvas;
import Robot.Fruit;
import Robot.Game;
import Robot.Packman;
import Robot.Play;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * An {@code java.awt.ActionListener} class that periodically updates the
 * the state of the game elements such as the pacment, the player and the ghosts.
 */
public class GameListener implements ActionListener {
    private Canvas canvas;
    private Play play;
    private MyCoords coords = new MyCoords();

    /**
     * Constructor.
     * @param canvas the canvas on which the game is drawn.
     */
    public GameListener(Canvas canvas){
        this.canvas = canvas;

        if(canvas.getGame() != null){
            play = new Play(canvas.getGame());
        }
    }


    /**
     * The method to be called whenever an action event is raised.
     * @param actionEvent the action event object.
     */
    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        // get the current game object.
        Game game = canvas.getGame();
        if(game != null){ // ensure it is non-null
            if(play == null){
                // create a play object from the game.
                play = new Play(game);
            }

            if(!play.isRuning()){
                // if the game is not yet being played, then start it.
                play.start();
            }

            // execute the code to update the game state.
            runGame(game);

            // re-draw the game elements.
            canvas.repaint();
        }

    }

    /**
     * Reset the game listener.
     */
    public void reset(){
        if(play != null){
            // stop the current game being played.
            play.stop();
            play = null;
        }
    }

    /**
     * Run the game logic.
     * @param game The game logic.
     */
    private void runGame(Game game) {
        // get the current player.
        Packman player = game.getPlayer();

        // move the ghosts toward our player.
        for(Packman ghost : game.getGhosts()){
            ghost.setOrientation(player.getLocation());
            ghost.set_speed(11);
            ghost.move(100.0D);
        }

        boolean shouldContinue;

        // move our player
        shouldContinue = movePlayer(player, game);

        // move all the packmen
        for(Packman packman : game.getRobots()){
            if(shouldContinue){
                shouldContinue = movePlayer(packman, game);
            }
        }
    }

    /**
     * Move a pacman from one position to another, typically towards the nearest fruit.
     * @param packman the pacman to be moved.
     * @param game the current game object
     * @return whether a further move is possible after the current one.
     */
    private boolean movePlayer(Packman packman, Game game){
        // whether further player movement is possible
        boolean shouldContinueMovement = true;

        // get the nearest fruit to the pacman
        Fruit fruit = getNearestFruit(game.getTargets(), packman);
        if(null != fruit){ // check if there is a fruit found
            packman.setOrientation(fruit.getLocation());
            if (packman.distance3D(fruit) < packman.get_radius()) {
                // eat the fruit, if it is within reach.
                game.getTargets().remove(fruit);

                // check whether there are more fruits.
                if (game.sizeT() == 0) {
                    shouldContinueMovement = false;
                }
            }
            // move the pacman
            packman.move(100.0d);

        } else{
            shouldContinueMovement = false;
        }
        return shouldContinueMovement;
    }

    /**
     * Get the nearest fruit.
     * @param fruits the collection of fruits.
     * @param packman the pacman seeking fruits.
     * @return the nearest fruit to the {@param pacman} if the fruit
     *     exist. Otherwise return null.
     */
    private Fruit getNearestFruit(ArrayList<Fruit> fruits, Packman packman){
        Fruit r = null;
        double shortestDistance = 0;


        for(Fruit fruit : fruits){
            if(r == null){
                // assign the first fruit
                r = fruit;
                shortestDistance = coords.distance3d(packman.getLocation(), fruit.getLocation());
            } else if(coords.distance3d(packman.getLocation(), fruit.getLocation()) < shortestDistance) {
                // assign the current fruit as it's distance is shorter than the one previously saved.
                r = fruit;
                shortestDistance = coords.distance3d(packman.getLocation(), fruit.getLocation());
            }
        }
        return r;
    }
}
