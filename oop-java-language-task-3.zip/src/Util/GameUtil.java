package Util;

import Coords.GeoBox;
import Robot.Fruit;
import Robot.Game;
import Robot.Packman;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.PrintWriter;

/**
 * The {@code GameUtil} class houses utility methods used to load or save
 * {@code Robot.Game} object instances.
 */
public abstract class GameUtil {

    /**
     * Load a new game from a CSV file.
     * @return a new {@code Robot.Game} object instance if the looading operation was successful. Otherwise,
     * {@code null} is returned.
     */
    public static Game loadGame() {
        JFileChooser chooser = new JFileChooser();
        //only csv files
        chooser.setFileFilter(new FileNameExtensionFilter("CSV file", "csv"));
        chooser.showOpenDialog(null);
        chooser.setCurrentDirectory(new File("config"));
        File chosenFile = chooser.getSelectedFile();
        if(chosenFile != null){
            Game game = new Game(chosenFile.getPath());

            // set 'null' as default player
            game.setPlayer(null);

            return game;
        }
        return null;
    }


    /**
     * Save an existing {@code Robot.Game} object to a CSV file.
     * @param game The game to be saved.
     */
    public static void saveGame(Game game) {
        if (null != game) {
            StringBuilder sb = generateHeader(game);

            // add packmen
            for(Packman p : game.getRobots()){
                addPackmanOrGhost(sb, p, "P");
            }

            // add ghosts
            for(Packman p : game.getGhosts()){
                addPackmanOrGhost(sb, p, "G");
            }

            // add fruits
            for(Fruit f : game.getTargets()){
                addFruit(sb, f);
            }

            // append geo-boxes
            for(int i = 0; i < game.sizeB(); i++){
                addBox(sb, game.getBox(i));
            }

            // time to write the game to file
            try(PrintWriter pw = new PrintWriter("config/" + game.hashCode() + ".csv")){
                pw.write(sb.toString());
                pw.flush();
                JOptionPane.showMessageDialog(null, "Game saved as " + game.hashCode()
                        + ".csv in the config folder", "Save Error", JOptionPane.INFORMATION_MESSAGE);
            }catch (Exception e){
                JOptionPane.showMessageDialog(null, "I/O Error", "Save Error", JOptionPane.ERROR_MESSAGE);
            }

        } else {
            JOptionPane.showMessageDialog(null, "No game found!", "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Genearate the CSV header line.
     * @param game the {@code Robot.Game}
     * @return a {@code java.lang.StringBuilder} containing the header line.
     */
    private static StringBuilder generateHeader(Game game) {
        StringBuilder sb = new StringBuilder();
        sb.append("Type")
                .append(",")
                .append("id")
                .append(",")
                .append("Lat")
                .append(',')
                .append("Lon")
                .append(',')
                .append("Alt")
                .append(',')
                .append("Speed/Weight")
                .append(',')
                .append("Radius")
                .append(',')
                .append(game.sizeR())
                .append(',')
                .append(game.sizeT())
                .append(game.sizeG())
                .append('\n');

        return sb;
    }

    /**
     * Add a pacman or a ghost object to the string builder
     * @param sb the string builder to append the the ghost or pacman
     * @param p the pacman/ghost to be appended to the string builder
     * @param prefix the prefix, 'G' for ghost or 'P' for pacman.
     */
    private static void addPackmanOrGhost(StringBuilder sb, Packman p, String prefix) {
        // first extract the packman's ID, as it is not part of
        // the public API, but available as part of packman's
        // string representation
        String id = p.toString().split(",")[1];

        sb.append(prefix)
                .append(',')
                .append(id)
                .append(',')
                .append(p.getLocation().x())
                .append(',')
                .append(p.getLocation().y())
                .append(',')
                .append(p.getLocation().z())
                .append(',')
                .append(p.get_speed())
                .append(',')
                .append(p.get_radius())

                .append('\n');

    }

    /**
     * Add the fruit to the string builder.
     * @param sb the string builder on to which to append the fruit.
     * @param f the fruit to be added.
     */
    private static void addFruit(StringBuilder sb, Fruit f) {
        // first extract the fruit's ID, as it is not part of
        // the public API, but available as part of fruit's
        // string representation
        String id = f.toString().split(",")[1];

        sb.append("F")
                .append(',')
                .append(id)
                .append(',')
                .append(f.getLocation().x())
                .append(',')
                .append(f.getLocation().y())
                .append(',')
                .append(f.getLocation().z())
                .append(',')
                .append(f.getWeight())
                .append(',')

                .append('\n');
    }

    /**
     * Add a box.
     * @param sb the string builder on to which to append the geobox.
     * @param b the box to be appended to the string builder.
     */
    private static void addBox(StringBuilder sb, GeoBox b) {
        // first extract the GeoBox's ID, as it is not part of
        // the public API, but available as part of GeoBox's
        // string representation
        String id = b.toString().split(",")[1];

        sb.append("B")
                .append(',')
                .append(id)
                .append(',')
                .append(b.getMin().x())
                .append(',')
                .append(b.getMin().y())
                .append(',')
                .append(b.getMin().z())
                .append(',')
                .append(b.getMax().x())
                .append(',')
                .append(b.getMax().y())
                .append(',')
                .append(b.getMax().z())
                .append(',')
                .append(b.getWeight())

                .append('\n');
    }

}
