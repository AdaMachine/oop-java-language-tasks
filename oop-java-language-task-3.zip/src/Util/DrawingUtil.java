package Util;

import Coords.GeoBox;
import Coords.LatLonAlt;
import Coords.MyMap;
import Geom.Point3D;
import Robot.Packman;
import Robot.Fruit;

import java.awt.*;

/**
 * The {@code DrawUtil} class houses utility methods for drawing various game elements.
 */
public abstract class DrawingUtil {
    public static void drawMap(Graphics graphics, MyMap map){
        // draw the image iff it is non-null
        if(null != map.getImage()){
            graphics.drawImage(map.getImage(), 0, 0, (int)map.getWidth(),
                    (int)map.getHeight(), null);
        }
    }


    /**
     * Draw the player of a user.
     * @param graphics The graphics context to be used for drawing.
     * @param map The map to use.
     * @param packman The player to be drawn.
     */
    public static void drawPlayer(Graphics graphics, MyMap map, Packman packman){
        // convert the packman co-ords to pixels
        Point3D point3D = map.coords2Pixels(packman.getLocation(), (int)map.getHeight(), (int)map.getWidth());
        graphics.setColor(Color.PINK);

        // scale up packman's radius
        int radius = (int) (packman.get_radius() * 50);

        // draw the packman
        graphics.fillArc(point3D.ix(), point3D.iy(), radius, radius,0, 360);
    }

    /**
     * Draw a regular pacman.
     * @param graphics The graphics context to be used for drawing.
     * @param map The map to use.
     * @param packman The pacman to be drawn.
     */
    public static void drawRobot(Graphics graphics, MyMap map, Packman packman){
        // convert the packman co-ords to pixels
        Point3D point3D = map.coords2Pixels(packman.getLocation(), (int)map.getHeight(), (int)map.getWidth());
        graphics.setColor(Color.YELLOW);

        // scale up packman's radius
        int radius = (int) (packman.get_radius() * 50);

        // draw the packman
        graphics.fillArc(point3D.ix(), point3D.iy(), radius, radius,0, 360);
    }

    /**
     * Draw a ghost.
     * @param graphics The graphics context to be used for drawing.
     * @param map The map to use.
     * @param packman The ghost to be drawn.
     */
    public static void drawGhost(Graphics graphics, MyMap map, Packman packman){
        // convert the packman co-ords to pixels
        Point3D point3D = map.coords2Pixels(packman.getLocation(), (int)map.getHeight(), (int)map.getWidth());
        graphics.setColor(Color.RED);

        // draw the packman
        graphics.fillArc(point3D.ix(), point3D.iy(), 50, 50,0, 360);
    }

    /**
     * Draw a fruit.
     * @param graphics The graphics context to be used for drawing.
     * @param map The map to use.
     * @param fruit The fruit to be drawn.
     */
    public static void drawFruit(Graphics graphics, MyMap map, Fruit fruit){
        // convert the packman co-ords to pixels
        Point3D point3D = map.coords2Pixels(fruit.getLocation(), (int)map.getHeight(), (int)map.getWidth());
        graphics.setColor(Color.GREEN);

        // draw the packman
        graphics.fillArc(point3D.ix(), point3D.iy(), 26, 26,0, 360);
    }

    /**
     * Draw a geo-box.
     * @param g The graphics context to be used for drawing.
     * @param map The map to use.
     * @param geoBox The geo-box to be drawn.
     */
    public static void drawBox(Graphics g, MyMap map, GeoBox geoBox){
        g.setColor(Color.BLACK);
        Point3D minPoint = map.coords2Pixels(geoBox.getMin(), (int)map.getHeight(), (int)map.getWidth());
        Point3D maxPoint = map.coords2Pixels(geoBox.getMax(), (int)map.getHeight(), (int)map.getWidth());

        int width = maxPoint.ix() - minPoint.ix();
        int height = minPoint.iy() - maxPoint.iy();

        g.fillRect(minPoint.ix(), maxPoint.iy(),  width, height);
    }

}
