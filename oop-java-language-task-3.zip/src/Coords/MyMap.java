package Coords;

import Geom.Point3D;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class MyMap {

	private BufferedImage image;
	private Point3D buttom_right = new Point3D(32.102091,35.212225);
	private Point3D upper_left = new Point3D(32.105767,35.201958);

	private double indicatorX ; 
	private double indicatorY ;

	private double indicatorX1 ;
	private double indicatorY1 ;

	/**
	 *  Construct a new instance of {@code MyMap} class.
	 */
	public MyMap() {
		// load the map image
		this.image = loadImage();
	}

	/**
	 * @return a buffered image loaded from the map image.
	 */
	private BufferedImage loadImage(){
		try{
			return ImageIO.read(new File("data/Ariel1.png"));
		}catch (Exception e){
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Convert co-ordinate to pixels.
	 * @param gps the point to be converted.
	 * @param height height of the program window.
	 * @param width width of the program window.
	 * @return the point in pixels as converted by this method.
	 */
	public Point3D coords2Pixels(Point3D gps, int height, int width ) {

		indicatorX = width / (Math.abs(buttom_right.y() - upper_left.y()));
		indicatorY = height / (Math.abs(buttom_right.x() - upper_left.x()));
		
		double disY = Math.abs(gps.x() - upper_left.x());
		double disX = Math.abs(gps.y() - upper_left.y());
		double x = disX * indicatorX;
		double y = disY * indicatorY;

		return new Point3D(x,y);

	}

	/**
	 * Convert pixels to co-ordinates.
	 * @param temp the point in pixels to be converted.
	 * @param height the height of the program window.
	 * @param width the width of the program window.
	 * @return the converted point as co-ordinates.
	 */
	public Point3D pixels2Coords(Point3D temp, int height, int width) {
		 indicatorX1 = (Math.abs(buttom_right.y() - upper_left.y())) / width;
		 indicatorY1 = (Math.abs(buttom_right.x() - upper_left.x())) / height;
		
		double y= upper_left.y() - temp.x()*indicatorX1;

		double x= upper_left.x() - temp.y()*indicatorY1;
		

		return new Point3D(x,y);
	}

	/**
	 * @return the height of the program window.
	 */
	public int getHeight(){
		return this.image.getHeight() + 50;
	}

	/**
	 *
	 * @return the width of the program window.
	 */
	public int getWidth(){
		return  this.image.getWidth();
	}

	/**
	 * Calculate the distance between any two given points.
	 * @param p1 source point.
	 * @param p2 destination point.
	 * @return
	 */
	public double distance(Point3D p1, Point3D p2) {
		return p1.distance2D(p2);
	}

	/**
	 * @return the buffered image object of the satellite image used by the program map.
	 */
	public BufferedImage getImage() {
		return image;
	}

}