package GUI;

/**
 *  The main class is the entry point of the whole game.
 */
public class Main {
    /**
     * Entry point of the progam.
     * @param args command-line arguments.
     */
    public static void main(String[] args){
        MainWindow mainWindow = new MainWindow();
        mainWindow.setVisible(true);
    }
}
