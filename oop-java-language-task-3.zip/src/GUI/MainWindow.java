package GUI;

import Coords.LatLonAlt;
import Coords.MyMap;
import Geom.Point3D;
import Listeners.*;
import Robot.Game;
import Util.DrawingUtil;
import Util.GameUtil;
import Robot.Packman;
import Robot.Play;

import javax.swing.*;
import java.awt.*;

/**
 *  Render the main window
 */
public class MainWindow extends JFrame{
    // create menu-bar, menus and menu items
    private MenuBar menuBar;
    private Menu mGame;
    private Menu mInsert;

    private MenuItem mPacman;
    private MenuItem mFruit;
    private MenuItem mGhost;

    private MenuItem mRun;
    private MenuItem mClear;
    private MenuItem mLoad;
    private MenuItem mSave;
    private MenuItem mOver;
    private MenuItem mClearInsert;
    private MenuItem mPlayer;

    // canvas
    private Canvas canvas;

    // listeners
    private AddPackmanMouseListener addPackmanMouseListener;
    private AddFruitMouseListener addFruitMouseListener;
    private AddGhostMouseListener addGhostMouseListener;
    private AddPlayerMouseListener addPlayerMouseListener;

    // play object
    private Play play;

    // timer object
    private Timer timer;

    // game listener object to driver the timer
    private GameListener gameListener;


    /**
     *  Constructor
     */
    public MainWindow(){
        // the current map
        MyMap map = new MyMap();

        this.setSize((int) map.getWidth(), (int) map.getHeight());
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        initMenuBar();
        attachMenuListeners();
        this.canvas = new Canvas(null, map);

        // load the canvas.
        this.getContentPane().add(canvas, BorderLayout.CENTER);

        // init listeners
        addPackmanMouseListener = new AddPackmanMouseListener(this.canvas);
        addFruitMouseListener = new AddFruitMouseListener(this.canvas);
        addGhostMouseListener = new AddGhostMouseListener(this.canvas);
        addPlayerMouseListener = new AddPlayerMouseListener(this.canvas);

        // create the game listener
        gameListener = new GameListener(this.canvas);

        // create the timer
        timer = new Timer(80, gameListener);
    }

    /**
     *  Create and set the menu-bar.
     */
    private void initMenuBar(){
        // create menu-bar, menus and menu items
        menuBar = new MenuBar();
        mGame = new Menu("Game");
        mInsert = new Menu("Insert");

        mPacman = new MenuItem("Pacman");
        mFruit = new MenuItem("Fruit");
        mGhost = new MenuItem("Ghost");

        mRun = new MenuItem("Run");
        mClear = new MenuItem("Clear Board");
        mLoad = new MenuItem("Load");
        mSave = new MenuItem("Save");
        mOver = new MenuItem("Game over");
        mClearInsert = new MenuItem("Clear Insert");
        mPlayer = new MenuItem("Player");

        // place the menus to the menu-bar
        menuBar.add(mGame);
        menuBar.add(mInsert);


        // place the menu-items to the menus
        mInsert.add(mPlayer);
        mInsert.add(mPacman);
        mInsert.add(mGhost);
        mInsert.add(mFruit);
        mInsert.add(mClearInsert);
        mInsert.add(mClear);

        mGame.add(mRun);
        mGame.add(mLoad);
        mGame.add(mSave);
        mGame.add(mOver);

        // set the menu-bar of the frame
        this.setMenuBar(menuBar);
    }

    /**
     * Attach menu listeners.
     */
    private void attachMenuListeners(){
        // quit system
        mOver.addActionListener(actionEvent -> System.exit(0));

        // load a new game
        mLoad.addActionListener(actionEvent -> {
            Game loadedGame = GameUtil.loadGame();
            if(loadedGame != null){
                this.canvas.setGame(loadedGame);
                this.gameListener.reset();
                this.timer.stop();
            }
            repaint();
        });

        // clear the game
        mClear.addActionListener(actionEvent -> {
            if(this.canvas.getGame() != null){
                this.canvas.getGame().clear();
            }
            repaint();
        });

        // save a game
        mSave.addActionListener(actionEvent -> GameUtil.saveGame(canvas.getGame()));

        // add a packman
        mPacman.addActionListener(actionEvent -> {
            if(canvas.getGame() != null){
                // detach any mouse motion listeners and reset canvas
                detachMouseListeners();

                canvas.addMouseMotionListener(addPackmanMouseListener);
                canvas.addMouseListener(addPackmanMouseListener);
            } else {
                JOptionPane.showMessageDialog(null, "Load a game first!", "Add Error", JOptionPane.ERROR_MESSAGE);
            }
        });


        // add a ghost
        mGhost.addActionListener(actionEvent -> {
            if(canvas.getGame() != null){
                // detach any mouse motion listeners and reset canvas
                detachMouseListeners();

                canvas.addMouseMotionListener(addGhostMouseListener);
                canvas.addMouseListener(addGhostMouseListener);
            } else {
                JOptionPane.showMessageDialog(null, "Load a game first!", "Add Error", JOptionPane.ERROR_MESSAGE);
            }
        });


        // add a fruit
        mFruit.addActionListener(actionEvent -> {
            if(canvas.getGame() != null){
                // detach any mouse motion listeners and reset canvas
                detachMouseListeners();

                canvas.addMouseMotionListener(addFruitMouseListener);
                canvas.addMouseListener(addFruitMouseListener);
            } else {
                JOptionPane.showMessageDialog(null, "Load a game first!", "Add Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // detach mouse listeners
        mClearInsert.addActionListener(actionEvent -> detachMouseListeners());

        // run the game
        mRun.addActionListener(actionEvent -> {
            if(canvas.getGame() == null){
                JOptionPane.showMessageDialog(null, "Load a game first!", "Play Error", JOptionPane.ERROR_MESSAGE);
            } else if(canvas.getGame().getPlayer() == null) {
                JOptionPane.showMessageDialog(null, "Add a player first!", "Play Error", JOptionPane.ERROR_MESSAGE);
            } else {
                timer.start();
            }
        });


        // add player
        mPlayer.addActionListener(actionEvent -> {
            if(canvas.getGame() == null){
                JOptionPane.showMessageDialog(null, "Load a game first!", "Add Error", JOptionPane.ERROR_MESSAGE);
            } else if(canvas.getGame().getPlayer() != null){
                JOptionPane.showMessageDialog(null, "You have already added a player", "Add Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // detach any mouse motion listeners and reset canvas
                detachMouseListeners();

                canvas.addMouseMotionListener(addPlayerMouseListener);
                canvas.addMouseListener(addPlayerMouseListener);
            }
        });

    }


    /**
     * Remove all the mouse listners from the canvas.
     */
    private void detachMouseListeners(){
        canvas.resetPseudoElements();

        canvas.removeMouseListener(addPackmanMouseListener);
        canvas.removeMouseMotionListener(addPackmanMouseListener);

        canvas.removeMouseListener(addFruitMouseListener);
        canvas.removeMouseMotionListener(addFruitMouseListener);

        canvas.removeMouseListener(addGhostMouseListener);
        canvas.removeMouseMotionListener(addGhostMouseListener);

        canvas.removeMouseListener(addPlayerMouseListener);
        canvas.removeMouseMotionListener(addPlayerMouseListener);

        repaint();
    }

}
