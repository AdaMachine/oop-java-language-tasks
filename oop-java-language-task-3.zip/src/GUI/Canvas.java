package GUI;

import javax.swing.*;
import java.awt.*;

import Coords.LatLonAlt;
import Coords.MyMap;
import Geom.Point3D;
import Robot.Game;
import Robot.Packman;
import Util.DrawingUtil;
import Robot.Fruit;

/**
 *  Use a special canvas to draw the objects. The reason is to customise a
 *  java.awt.Component#drawComponent method in order to avoid the flickering
 *  that comes when painting objects in using the java.awt.Component#paint method.
 */
public class Canvas extends JPanel {
    private Game game;
    private final MyMap map;

    // pseudo-packman. To be used when adding a new packman.
    private Packman pseudoPackman;

    // pseudo-ghost. To be used when adding a new packman.
    private Packman pseudoGhost;

    // pseudo-fruit to be used when adding a new fruit
    private Fruit pseudoFruit;

    // pseudo-player, to be used when adding a new player
    private Packman pseudoPlayer;

    /**
     * Constructor.
     * @param game the game to be rendered on the canvas.
     * @param map the map/arena on which to render the game.
     */
    public Canvas(Game game, MyMap map){
        this.game = game;
        this.map = map;
    }

    /**
     * @param game the new game to be set.
     */
    public void setGame(Game game){
        this.game = game;
    }

    /**
     * @return get the current game being rendered.
     */
    public Game getGame() {
        return game;
    }


    /**
     *  Accept (add to the game) the fruit being dragged on the screen before being added.
     */
    public void acceptPseudoFruit(){
        if(game != null){
            if(null != this.pseudoFruit){
                // clone a new fruit.
                Fruit f = new Fruit(this.pseudoFruit);

                // add this fruit to the game
                game.getTargets().add(f);

                // annul the current pseudo fruit
                this.pseudoFruit = null;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Load a game first!", "Add Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     *  Accept (add to the game) the player being dragged on the screen before being added to the game.
     */
    public void acceptPseudoPlayer(){
        if(game != null){
            if(null != this.pseudoPlayer){
                // clone a new player.
                Packman p = new Packman(this.pseudoPlayer);

                // set this player as the current player
                game.setPlayer(p);

                // annul the current player ghost
                this.pseudoPlayer = null;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Load a game first!", "Add Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     *  Accept (add to the game) the ghost being dragged on the screen before being added to the game.
     */
    public void acceptPseudoGhost(){
        if(game != null){
            if(null != this.pseudoGhost){
                // clone a new ghost.
                Packman p = new Packman(this.pseudoGhost);

                // add this ghost to the game
                game.getGhosts().add(p);

                // annul the current pseudo ghost
                this.pseudoGhost = null;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Load a game first!", "Add Error", JOptionPane.ERROR_MESSAGE);
        }

    }
    /**
     *  Accept (add to the game) the pacman (here, the pacman refers to any other pacman that is NOT
     *  the user's player) being dragged on the screen before being added.
     */
    public void acceptPseudoPacman(){
        if(game != null){
            if(null != this.pseudoPackman){
                // clone a new pacman.
                Packman p = new Packman(pseudoPackman);

                // add this pacman to the game
                game.getRobots().add(p);

                // annul the current pseudo pacman
                this.pseudoPackman = null;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Load a game first!", "Add Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    /**
     *  Reset the false pacmen, ghost, fruit and user's player. These are are the ones used
     *  to simulate the true game elements when adding them to the game.
     */
    public void resetPseudoElements(){
        this.pseudoPackman = null;
        this.pseudoFruit = null;
        this.pseudoGhost = null;
        this.pseudoPlayer = null;
    }

    /**
     * Update the position of the pseudo-ghost, to reflect a movement on the screen along with the mouse.
     * @param x the X position
     * @param y the Y position
     */
    public void updatePseudoGhost(int x, int y){
        // ensure the mouse pointer points to the center of the ghost
        x = x - 25;
        y = y - 25;

        // convert mouse pixels to co-ords.
        Point3D tempPoint = map.pixels2Coords(new Point3D(x, y, 0), this.map.getHeight()
                , this.map.getWidth());
        LatLonAlt newLocation = new LatLonAlt(tempPoint.x(), tempPoint.y(), tempPoint.z());

        if(null == pseudoGhost){
            pseudoGhost = new Packman(newLocation, 0);
        } else {
            pseudoGhost.setLocation(newLocation);
        }

        repaint();
    }


    /**
     * Update the position of the pseudo-pacman, to reflect a movement on the screen along with the mouse.
     * @param x the X position
     * @param y the Y position
     */
    public void updatePseudoPacman(int x, int y){
        // ensure the mouse pointer points to the center of the pacman
        x = x - 25;
        y = y - 25;

        // convert mouse pixels to co-ords.
        Point3D tempPoint = map.pixels2Coords(new Point3D(x, y, 0), this.map.getHeight()
                , this.map.getWidth());

        LatLonAlt newLocation = new LatLonAlt(tempPoint.x(), tempPoint.y(), tempPoint.z());

        if(null == pseudoPackman){
            pseudoPackman = new Packman(new LatLonAlt(0, 0, 0), 10.0);
        } else {
            pseudoPackman.setLocation(newLocation);

        }

        repaint();
    }

    /**
     *
     * @return the map the canvas is using to draw the game on.
     */
    public MyMap getMap() {
        return map;
    }

    /**
     * Update the position of the pseudo-player, to reflect a movement on the screen along with the mouse.
     * @param x the X position
     * @param y the Y position
     */
    public void updatePseudoPlayer(int x, int y){
        // ensure the mouse pointer points to the center of the pacman
        x = x - 25;
        y = y - 25;

        // convert mouse pixels to co-ords.
        Point3D tempPoint = map.pixels2Coords(new Point3D(x, y, 0), this.map.getHeight()
                , this.map.getWidth());
        LatLonAlt newLocation = new LatLonAlt(tempPoint.x(), tempPoint.y(), tempPoint.z());

        if(null == pseudoPlayer){
            pseudoPlayer = new Packman(newLocation, 0);
        } else {
            pseudoPlayer.setLocation(newLocation);
        }

        repaint();
    }

    /**
     * Update the position of the pseudo-fruit, to reflect a movement on the screen along with the mouse.
     * @param x the X position
     * @param y the Y position
     */
    public void updatePseudoFruit(int x, int y){
        // ensure the mouse pointer points to the center of the fruit.
        x = x - 13;
        y = y - 13;

        // convert mouse pixels to co-ords.
        Point3D tempPoint = map.pixels2Coords(new Point3D(x, y, 0), this.map.getHeight()
                , this.map.getWidth());
        LatLonAlt newLocation = new LatLonAlt(tempPoint.x(), tempPoint.y(), tempPoint.z());
        pseudoFruit = new Fruit(newLocation);

        repaint();
    }

    /**
     * Paint this {@code Component} class (or sub-class) on the screen using the given
     * graphics context.
     * @param g Graphic context.
     */
    @Override
    public void paintComponent(Graphics g){
        // draw the map.
        DrawingUtil.drawMap(g, map);

        // draw the game elements if the game is not null.
        if(game != null){
            // draw the robots.
            game.getRobots().forEach(robot -> DrawingUtil.drawRobot(g, map, robot));

            // draw the ghosts
            game.getGhosts().forEach(ghost -> DrawingUtil.drawGhost(g, map, ghost));

            // draw fruits
            game.getTargets().forEach(fruit -> DrawingUtil.drawFruit(g, map, fruit));

            // draw the boxes
            for(int i = 0; i < game.sizeB(); i++){
                DrawingUtil.drawBox(g, map, game.getBox(i));
            }

            // draw the player if it exists
            if(game.getPlayer() != null){
                DrawingUtil.drawPlayer(g, map, game.getPlayer());
            }
        }

        // draw pseudo-pacman if it exists
        if(pseudoPackman != null){
            DrawingUtil.drawRobot(g, map, pseudoPackman);
        }

        // draw pseudo-ghost if it exists
        if(pseudoGhost != null){
            DrawingUtil.drawGhost(g, map, pseudoGhost);
        }

        // draw pseudo-player if it exists
        if(pseudoPlayer != null){
            DrawingUtil.drawPlayer(g, map, pseudoPlayer);
        }

        // draw pseudo-fruit if it exists
        if(pseudoFruit != null){
            DrawingUtil.drawFruit(g, map, pseudoFruit);
        }
    }
}
