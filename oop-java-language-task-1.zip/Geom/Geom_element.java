package Geom;

public interface Geom_element {//this interface is implemented on point3d
	
	public double distance3D(Point3D p) ;
	public double distance2D(Point3D p);
	
}
